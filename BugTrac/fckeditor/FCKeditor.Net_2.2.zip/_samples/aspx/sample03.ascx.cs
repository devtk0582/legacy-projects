namespace FredCK.FCKeditorV2.Samples
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;

	public class sample031 : System.Web.UI.UserControl
	{
		protected FredCK.FCKeditorV2.FCKeditor FCKeditor1 ;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// We'll do initializartion settings in the editor only the first time.
			// Once the page is submitted, nothing must be done in the OnLoad.
			if ( Page.IsPostBack )
				return ;

			// Automatically calculates the editor base path based on the _samples directory.
			// This is usefull only for these samples. A real application should use something like this:
			// FCKeditor1.BasePath = '/FCKeditor/' ;	// '/FCKeditor/' is the default value.
			string sPath = Request.Url.AbsolutePath ;
			int iIndex = sPath.LastIndexOf( "_samples") ;
			sPath = sPath.Remove( iIndex, sPath.Length - iIndex  ) ;
			
			FCKeditor1.BasePath = sPath ;
			FCKeditor1.Value = "This is some <strong>sample text</strong>. You are using <a href=\"http://www.fckeditor.net/\">FCKeditor</a>." ;
			FCKeditor1.ImageBrowserURL	= sPath + "editor/filemanager/browser/default/browser.html?Type=Image&Connector=connectors/aspx/connector.aspx" ;
			FCKeditor1.LinkBrowserURL	= sPath + "editor/filemanager/browser/default/browser.html?Connector=connectors/aspx/connector.aspx" ;
		}

		public string GetFCKeditorValue()
		{
			return FCKeditor1.Value ;
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);

			// This events declarations has been moved to the "OnInit" method
			// to avoid a bug in Visual Studio to delete then without any advice.
			this.Load += new System.EventHandler(this.Page_Load);
		}
		
		/// <summary>
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{

		}
		#endregion
	}
}
